/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flujos;

/**
 *
 * @author Pablo
 */
public class FlujoA extends Thread{
    double random = Math.random();
    int tEspera = (int)(random * 100) +1;
    public void run(){
        try {
                for (int i =0; i <= 10; i++){
                    System.out.println("Flujo A" + i);
                    sleep(tEspera);
            
                } 
        }
    
        catch (InterruptedException e ){
                    e.printStackTrace(); 
        }   
    }  
}

