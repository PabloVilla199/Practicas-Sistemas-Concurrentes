/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package flujos;

/**
 *
 * @author Pablo
 */
public class Flujos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FlujoA f1 = new FlujoA();
        FlujoB f2 = new FlujoB();
        FlujoC f3 = new FlujoC();
        
        f1.start();
        f2.start();
        f3.start();
    }
    
}
