/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flujos;

import static java.lang.Thread.sleep;

/**
 *
 * @author Pablo
 */
public class FlujoB  extends Thread{
 double random = Math.random();
    int tEspera = (int)(random * 100) +1;
    public void run(){
        try {
                for (int i =0; i <= 15; i++){
                    System.out.println("Flujo B"+ i);
                    sleep(tEspera);
            
                } 
        }
    
        catch (InterruptedException e ){
                    e.printStackTrace(); 
        }   
    }  
    
}
